//
//  ViewController.swift
//  MergeImage
//
//  Created by ShadhiN on 14/1/22.
//

import UIKit
import AVFoundation
class ViewController: UIViewController {

    @IBOutlet weak var iv4: UIImageView!
    @IBOutlet weak var iv3: UIImageView!
    @IBOutlet weak var iv2: UIImageView!
    @IBOutlet weak var iv1: UIImageView!
    @IBOutlet weak var ivMergedImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url1 = URL(string: "https://i.ibb.co/VWySMMr/1.png")
        DispatchQueue.global().async {
            let data = try? Data(contentsOf: url1!) //make sure your image in this url does exist, otherwise unwrap in a if let check / try-catch
            DispatchQueue.main.async {
                self.iv1.image = UIImage(data: data!)
            }
        }
        let url2 = URL(string: "https://i.ibb.co/b2D0SsH/2.png")
        DispatchQueue.global().async {
            let data = try? Data(contentsOf: url2!) //make sure your image in this url does exist, otherwise unwrap in a if let check / try-catch
            DispatchQueue.main.async {
                self.iv2.image = UIImage(data: data!)
            }
        }
        let url3 = URL(string: "https://i.ibb.co/kHbhKX4/3.png")
        DispatchQueue.global().async {
            let data = try? Data(contentsOf: url3!) //make sure your image in this url does exist, otherwise unwrap in a if let check / try-catch
            DispatchQueue.main.async {
                self.iv3.image = UIImage(data: data!)
            }
        }
        let url4 = URL(string: "https://i.ibb.co/0MN8jHq/4.png")
        DispatchQueue.global().async {
            let data = try? Data(contentsOf: url4!) //make sure your image in this url does exist, otherwise unwrap in a if let check / try-catch
            DispatchQueue.main.async {
                self.iv4.image = UIImage(data: data!)
            }
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 7.0) { [self] in // Change `2.0` to the desired number of seconds.
             
            let firstTwoImage=stitchImages(images: [self.iv1.image!,self.iv2.image!],isVertical: false)
            let lastTwoImage=stitchImages(images: [self.iv3.image!,self.iv4.image!],isVertical: false)
            ivMergedImage.image = stitchImages(images: [firstTwoImage,lastTwoImage],isVertical: true)
        
        }
        
    }
    func stitchImages(images: [UIImage], isVertical: Bool) -> UIImage {
        var stitchedImages : UIImage!
        if images.count > 0 {
            var maxWidth = CGFloat(0), maxHeight = CGFloat(0)
            for image in images {
                if image.size.width > maxWidth {
                    maxWidth = image.size.width
                }
                if image.size.height > maxHeight {
                    maxHeight = image.size.height
                }
            }
            var totalSize : CGSize
            let maxSize = CGSize(width: maxWidth, height: maxHeight)
            if isVertical {
                totalSize = CGSize(width: maxSize.width, height: maxSize.height * (CGFloat)(images.count))
            } else {
                totalSize = CGSize(width: maxSize.width  * (CGFloat)(images.count), height:  maxSize.height)
            }
            UIGraphicsBeginImageContext(totalSize)
            for image in images {
                let offset = (CGFloat)(images.firstIndex(of: image)!)
                let rect =  AVMakeRect(aspectRatio: image.size, insideRect: isVertical ?
                                CGRect(x: 0, y: maxSize.height * offset, width: maxSize.width, height: maxSize.height) :
                                CGRect(x: maxSize.width * offset, y: 0, width: maxSize.width, height: maxSize.height))
                image.draw(in: rect)
            }
            stitchedImages = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
        }
        return stitchedImages
    }

}
