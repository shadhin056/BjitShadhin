# BdJobs Task

<img width="737" alt="Screenshot at Jul 01 23-48-01" src="https://user-images.githubusercontent.com/16523273/124170010-b9c5e280-dac8-11eb-9249-8d96004868d8.png">


## Title  : Problem solution Using Kotlin

## Description: 
Every winter Konka and Titli donate warm blankets with the help of their Dadajan.
Following the ritual, this year Konka has collected 53 blankets and Titli has collected 36 blankets.
But due to the ongoing pandemic, they cannot do it in person. So, they thought about distributing them through NGOs.
As they are not good with math, they went to Anis Bhai for a suggestion.
Anis Bhai introduced them with the Fibonacci sequence which is a series of numbers where a number is the addition of the last two numbers.
Following Anis Bhai’s idea, how many NGOs can they help?


## Technologies Used 
* Kotlin Programming Language
 
