
fun main(args: Array<String>) {
    val arrayOfValue = intArrayOf(1,2,5)
    val arraySize = arrayOfValue.size
    val targetValue = 11
    val minValue= getMinValue(arrayOfValue, arraySize, targetValue)
    if(minValue>arraySize){
        println("Minimum Value required is -1")
    }else{
        println("Minimum Value required is " + minValue)
    }

}
    fun getMinValue(values: IntArray, size: Int, targetValue: Int): Int {

        if (targetValue == 0) return 0
        var res = Int.MAX_VALUE

        for (i in 0 until size) {
            if (values[i] <= targetValue) {
                val sub_res = getMinValue(values, size, targetValue - values[i])

                if (sub_res != Int.MAX_VALUE && sub_res + 1 < res) res = sub_res + 1
            }
        }
        return res
    }
