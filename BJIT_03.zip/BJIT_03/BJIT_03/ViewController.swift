//
//  ViewController.swift
//  BJIT_03
//
//  Created by ShadhiN on 14/1/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var outerStackView: UIStackView!
    override func viewDidLoad() {
        super.viewDidLoad() 
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        print("Will Transition to size \(size) from super view size \(self.view.frame.size)")

        if (size.width > self.view.frame.size.width) {
            print("Landscape")
            outerStackView?.axis = .horizontal
            outerStackView?.distribution = .fillEqually

        } else {
            print("Portrait")
            outerStackView?.axis = .vertical
            outerStackView?.distribution = .fillEqually
        }
 

    }

}

